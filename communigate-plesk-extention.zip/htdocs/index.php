<?php

pm_Context::init('communigate');

$application = new pm_Application();
$application->run();
