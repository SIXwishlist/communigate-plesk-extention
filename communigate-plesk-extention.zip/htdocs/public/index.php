<?php

require_once('pm/Loader.php');
pm_Loader::registerAutoload();

echo 'You can see it bypass authorization.';
