<?php 

include 'CLI.php';


$host = "77.77.150.135";
$port = 11106;
$login = "postmaster";
$password = "jR6]FKhi";
$cli = new Modules_Example_CLI_CLI();
$cli->setDebug(1);
$cli->Login($host,$port,$login,$password);

function getAccountTypes($domain, $cli)
{
    // $cli = Modules_Communigate_Custom_Accounts::ConnectToCG($domain);

    $defaults = $cli->GetAccountDefaults($domain);
    $serverDefaults = $cli->SendCommand('GETSERVERACCOUNTDEFAULTS');
    $serverDefaults = $cli->parseWords($cli->getWords());


    if (empty($defaults['ServiceClasses']) &&  empty($serverDefaults["ServiceClasses"])) {
     	return array();   
    } elseif (empty($defaults['ServiceClasses'])) {
        $sc = array_keys($serverDefaults["ServiceClasses"]);
        return array_combine($sc, $sc);
    } elseif (empty($serverDefaults["ServiceClasses"])) {
		$sc = array_keys($defaults["ServiceClasses"]);
        return array_combine($sc, $sc);
    } else {
        $sc = array_keys($defaults["ServiceClasses"]);
        $defsc = array_keys($serverDefaults["ServiceClasses"]);
        $toRet = array_merge($sc, $defsc);
        return array_combine($toRet, $toRet);
    }
}

var_dump(getAccountTypes('abc.bg', $cli));


?>